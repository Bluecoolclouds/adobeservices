import { createStep, createWorkflow } from "../inngest";
import { z } from "zod";
import { getMenuResponseTool } from "../tools/getMenuResponse";
import { notifyManagerTool } from "../tools/sendTelegramResponse";
import * as fs from "fs";
import * as path from "path";

const InlineButtonSchema = z.object({
  text: z.string(),
  callback_data: z.string().optional(),
  url: z.string().optional(),
});

const processMessage = createStep({
  id: "process-message",
  description: "Processes the message using menu logic tool and prepares response",

  inputSchema: z.object({
    message: z.string().describe("User message from Telegram"),
    chatId: z.string().describe("Telegram chat ID"),
    userId: z.string().describe("Telegram user ID"),
    userName: z.string().optional().describe("Telegram username"),
    threadId: z.string().describe("Thread ID for tracking"),
  }),

  outputSchema: z.object({
    text: z.string(),
    inlineKeyboard: z.array(z.array(InlineButtonSchema)).optional(),
    chatId: z.string(),
    action: z.string(),
    photoUrl: z.string().optional(),
  }),

  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("🚀 [Step 1] Processing message with menu logic...", {
      message: inputData.message,
      chatId: inputData.chatId,
    });

    try {
      const result = await getMenuResponseTool.execute({
        context: {
          message: inputData.message,
          userId: inputData.userId,
          userName: inputData.userName,
        },
        mastra,
        runtimeContext: {} as any,
      });

      logger?.info("✅ [Step 1] Menu response generated", {
        action: result.action,
        hasPhoto: !!result.photoUrl,
      });

      if (result.notifyManager && result.orderDetails) {
        logger?.info("📣 [Step 1] Notifying manager about new order");
        await notifyManagerTool.execute({
          context: {
            userId: inputData.userId,
            userName: inputData.userName,
            orderId: result.orderDetails.orderId.toString(),
            subscriptionType: result.orderDetails.subscriptionType,
            amount: result.orderDetails.amount,
          },
          mastra,
          runtimeContext: {} as any,
        });
      }

      return {
        text: result.text,
        inlineKeyboard: result.inlineKeyboard,
        chatId: inputData.chatId,
        action: result.action,
        photoUrl: result.photoUrl,
      };
    } catch (error) {
      logger?.error("❌ [Step 1] Error processing message:", error);
      return {
        text: "Произошла ошибка. Попробуйте позже или обратитесь в поддержку @wpnetwork_sup",
        inlineKeyboard: [
          [{ text: "🎨 Adobe Creative Cloud", callback_data: "adobe_cc" }],
          [{ text: "📞 Поддержка", url: "https://t.me/wpnetwork_sup" }],
        ],
        chatId: inputData.chatId,
        action: "error",
      };
    }
  },
});

const sendTelegramResponse = createStep({
  id: "send-telegram-response",
  description: "Sends the response to Telegram (photo or text message)",

  inputSchema: z.object({
    text: z.string(),
    inlineKeyboard: z.array(z.array(InlineButtonSchema)).optional(),
    chatId: z.string(),
    action: z.string(),
    photoUrl: z.string().optional(),
  }),

  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional(),
    action: z.string(),
  }),

  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("📤 [Step 2] Sending response to Telegram...", {
      chatId: inputData.chatId,
      action: inputData.action,
      hasPhoto: !!inputData.photoUrl,
    });

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      logger?.error("❌ [Step 2] TELEGRAM_BOT_TOKEN not configured");
      return { success: false, action: inputData.action };
    }

    try {
      let result: any;

      if (inputData.photoUrl) {
        const photoPath = path.join(process.cwd(), "public/images/welcome.jpg");
        
        if (fs.existsSync(photoPath)) {
          logger?.info("📷 [Step 2] Sending photo from file:", { photoPath });
          
          const FormData = (await import("form-data")).default;
          const formData = new FormData();
          formData.append("chat_id", inputData.chatId);
          formData.append("photo", fs.createReadStream(photoPath));
          formData.append("caption", inputData.text);
          formData.append("parse_mode", "HTML");
          
          if (inputData.inlineKeyboard && inputData.inlineKeyboard.length > 0) {
            formData.append("reply_markup", JSON.stringify({ inline_keyboard: inputData.inlineKeyboard }));
          }

          const response = await fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
            method: "POST",
            body: formData as any,
          });

          result = await response.json();
        } else {
          logger?.warn("⚠️ [Step 2] Photo file not found, sending as text");
          const body: any = {
            chat_id: inputData.chatId,
            text: inputData.text,
            parse_mode: "HTML",
          };
          if (inputData.inlineKeyboard && inputData.inlineKeyboard.length > 0) {
            body.reply_markup = { inline_keyboard: inputData.inlineKeyboard };
          }
          const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          });
          result = await response.json();
        }
      } else {
        const body: any = {
          chat_id: inputData.chatId,
          text: inputData.text,
          parse_mode: "HTML",
        };

        if (inputData.inlineKeyboard && inputData.inlineKeyboard.length > 0) {
          body.reply_markup = { inline_keyboard: inputData.inlineKeyboard };
        }

        const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });

        result = await response.json();
      }

      if (!result.ok) {
        logger?.error("❌ [Step 2] Telegram API error:", { 
          error: result.description,
          error_code: result.error_code 
        });
        return { success: false, action: inputData.action };
      }

      logger?.info("✅ [Step 2] Response sent successfully", {
        messageId: result.result.message_id,
        action: inputData.action,
      });

      return { 
        success: true, 
        messageId: result.result.message_id,
        action: inputData.action,
      };
    } catch (error) {
      logger?.error("❌ [Step 2] Error sending message:", error);
      return { success: false, action: inputData.action };
    }
  },
});

export const adobeBotWorkflow = createWorkflow({
  id: "adobe-bot-workflow",

  inputSchema: z.object({
    message: z.string().describe("User message from Telegram"),
    chatId: z.string().describe("Telegram chat ID"),
    userId: z.string().describe("Telegram user ID"),
    userName: z.string().optional().describe("Telegram username"),
    threadId: z.string().describe("Thread ID for tracking"),
  }) as any,

  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional(),
    action: z.string(),
  }),
})
  .then(processMessage as any)
  .then(sendTelegramResponse as any)
  .commit();
